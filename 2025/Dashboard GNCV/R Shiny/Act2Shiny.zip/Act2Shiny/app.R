library(shiny)
library(ggplot2)
library(dplyr)
library(DT)
library(sf)
library(viridis)
library(leaflet)

# Cargar los datos
dataset <- read.csv("GNCV.csv", encoding = "UTF-8")
mapa_colombia <- st_read("COLOMBIA.shp")

# Conversión de variables necesarias
dataset$ANIO_VENTA <- as.character(dataset$ANIO_VENTA)
dataset$MES_VENTA <- sprintf("%02d", as.integer(dataset$MES_VENTA))
dataset$DIA_VENTA <- as.character(dataset$DIA_VENTA)
dataset$CODIGO_MUNICIPIO_DANE <- as.character(dataset$CODIGO_MUNICIPIO_DANE)

# Diccionario de variables amigables
nombre_amigable <- c(
  "EDS_ACTIVAS" = "EDS Activas",
  "NUMERO_DE_VENTAS" = "Número de Ventas",
  "VEHICULOS_ATENDIDOS" = "Vehículos Atendidos",
  "CANTIDAD_VOLUMEN_SUMINISTRADO" = "Volumen Suministrado"
)

meses_ordenados <- c("01", "02", "03", "04", "05", "06",
                     "07", "08", "09", "10", "11", "12")

# Agrupar datos para mapa
datos_agg <- dataset %>%
  group_by(DEPARTAMENTO) %>%
  summarise(
    EDS_ACTIVAS = sum(EDS_ACTIVAS, na.rm = TRUE),
    NUMERO_DE_VENTAS = sum(NUMERO_DE_VENTAS, na.rm = TRUE),
    VEHICULOS_ATENDIDOS = sum(VEHICULOS_ATENDIDOS, na.rm = TRUE),
    CANTIDAD_VOLUMEN_SUMINISTRADO = sum(CANTIDAD_VOLUMEN_SUMINISTRADO, na.rm = TRUE)
  )

# Unión con shapefile
mapa_datos <- mapa_colombia %>%
  left_join(datos_agg, by = c("DPTO_CNMBR" = "DEPARTAMENTO"))

# Interfaz UI
ui <- navbarPage("Dashboard de Ventas GNCV en Colombia",
                 
                 tabPanel("Contexto",
                          fluidPage(
                            h3("Información General"),
                            p("Este dashboard permite visualizar las ventas de Gas Natural Comprimido Vehicular (GNCV) en Colombia."),
                            p("Se incluyen datos como estaciones activas, volumen suministrado, vehículos atendidos y ventas, junto con herramientas interactivas."),
                            p("Los datos fueron extraídos del portal de datos abiertos del Gobierno Colombiano.")
                          )
                 ),
                 
                 tabPanel("Resumen",
                          fluidPage(
                            verbatimTextOutput("summary")
                          )
                 ),
                 
                 tabPanel("Histograma",
                          sidebarLayout(
                            sidebarPanel(
                              selectInput("variable", "Selecciona variable:",
                                          choices = setNames(names(nombre_amigable), nombre_amigable)),
                              sliderInput("bins", "Número de bins:", min = 5, max = 50, value = 20)
                            ),
                            mainPanel(
                              plotOutput("histPlot"),
                              textOutput("texto_histograma")
                            )
                          )
                 ),
                 
                 tabPanel("Dispersión",
                          sidebarLayout(
                            sidebarPanel(
                              selectInput("xvar", "Variable X:",
                                          choices = setNames(names(nombre_amigable), nombre_amigable),
                                          selected = "NUMERO_DE_VENTAS"),
                              selectInput("yvar", "Variable Y:",
                                          choices = setNames(names(nombre_amigable), nombre_amigable),
                                          selected = "CANTIDAD_VOLUMEN_SUMINISTRADO")
                            ),
                            mainPanel(
                              plotOutput("scatterPlot"),
                              textOutput("texto_dispersion")
                            )
                          )
                 ),
                 
                 tabPanel("Evolución en el Tiempo",
                          sidebarLayout(
                            sidebarPanel(
                              checkboxGroupInput("anio_evolucion", "Selecciona años:",
                                                 choices = unique(dataset$ANIO_VENTA),
                                                 selected = unique(dataset$ANIO_VENTA)),
                              selectInput("variable_evolucion", "Variable a mostrar:",
                                          choices = setNames(names(nombre_amigable), nombre_amigable),
                                          selected = "CANTIDAD_VOLUMEN_SUMINISTRADO")
                            ),
                            mainPanel(
                              plotOutput("evolucionPlot"),
                              textOutput("texto_evolucion")
                            )
                          )
                 ),
                 
                 tabPanel("Mapa Interactivo",
                          sidebarLayout(
                            sidebarPanel(
                              selectInput("variable_mapa", "Selecciona variable a visualizar:",
                                          choices = setNames(names(nombre_amigable), nombre_amigable),
                                          selected = "NUMERO_DE_VENTAS")
                            ),
                            mainPanel(
                              leafletOutput("mapa", height = 600)
                            )
                          )
                 )
)

# Lógica del servidor
server <- function(input, output, session) {
  
  output$summary <- renderPrint({
    summary(dataset)
  })
  
  output$histPlot <- renderPlot({
    ggplot(dataset, aes(x = .data[[input$variable]])) +
      geom_histogram(bins = input$bins, fill = "darkcyan", color = "white") +
      labs(title = paste("Histograma de", nombre_amigable[[input$variable]]),
           x = nombre_amigable[[input$variable]], y = "Frecuencia") +
      theme_minimal()
  })
  
  output$texto_histograma <- renderText({
    paste("Histograma de la variable", nombre_amigable[[input$variable]])
  })
  
  output$scatterPlot <- renderPlot({
    ggplot(dataset, aes(x = .data[[input$xvar]], y = .data[[input$yvar]])) +
      geom_point(color = "#00BFC4", alpha = 0.7) +
      labs(title = paste("Dispersión:", nombre_amigable[[input$xvar]], "vs", nombre_amigable[[input$yvar]]),
           x = nombre_amigable[[input$xvar]],
           y = nombre_amigable[[input$yvar]]) +
      theme_minimal()
  })
  
  output$texto_dispersion <- renderText({
    paste("Diagrama de dispersión entre", nombre_amigable[[input$xvar]], "y", nombre_amigable[[input$yvar]])
  })
  
  output$evolucionPlot <- renderPlot({
    data_evol <- dataset %>%
      filter(ANIO_VENTA %in% input$anio_evolucion) %>%
      group_by(ANIO_VENTA, MES_VENTA) %>%
      summarise(valor = sum(.data[[input$variable_evolucion]], na.rm = TRUE)) %>%
      mutate(MES_VENTA = factor(MES_VENTA, levels = meses_ordenados))
    
    ggplot(data_evol, aes(x = MES_VENTA, y = valor, color = ANIO_VENTA, group = ANIO_VENTA)) +
      geom_line(size = 1.2) +
      geom_point(size = 2) +
      labs(title = paste("Evolución Mensual de", nombre_amigable[[input$variable_evolucion]]),
           x = "Mes", y = nombre_amigable[[input$variable_evolucion]]) +
      theme_minimal()
  })
  
  output$texto_evolucion <- renderText({
    paste("Evolución de la variable", nombre_amigable[[input$variable_evolucion]], "durante el/los año(s):", paste(input$anio_evolucion, collapse = ", "))
  })
  
  output$mapa <- renderLeaflet({
    var <- input$variable_mapa
    pal <- colorNumeric(palette = "YlOrRd", domain = mapa_datos[[var]], na.color = "transparent")
    
    leaflet(mapa_datos) %>%
      addProviderTiles("CartoDB.Positron") %>%
      addPolygons(
        fillColor = ~pal(get(var)),
        weight = 1,
        opacity = 1,
        color = "white",
        dashArray = "3",
        fillOpacity = 0.8,
        highlight = highlightOptions(
          weight = 2,
          color = "#666",
          fillOpacity = 0.9,
          bringToFront = TRUE),
        label = ~paste0(DPTO_CNMBR, ": ", formatC(get(var), big.mark = ",")),
        labelOptions = labelOptions(
          style = list("font-weight" = "normal", padding = "3px 8px"),
          textsize = "13px",
          direction = "auto")
      ) %>%
      addLegend(pal = pal, values = ~get(var), title = nombre_amigable[[var]],
                opacity = 0.7, position = "bottomright")
  })
}

shinyApp(ui, server)
